CONST = "hiii!!"
import numpy as np
MY_ARRAY = np.array([1, 2, 3, 4])
print(MY_ARRAY)