from setuptools import setup, find_packages

# Define the setup function
setup()
