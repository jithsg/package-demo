import numpy as np
CONST = "hiii!!"
MY_ARRAY = np.array([1, 2, 3, 4])
print(MY_ARRAY)