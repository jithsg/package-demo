# import sys
# sys.path.append('/home/jithish/Documents/package/')
# # print(sys.path)

from package.file import CONST
print(CONST)