# package-demo
Dependency graph of the package
![Dependency graph](dependency-graph.png)
